# -*- coding: utf-8 -*-
"""Diálogo del plugin catSQLDialog para QGIS.

Carga los objetos desde PostgreSQL y genera estructuras SQL PostGIS
combinando atributos del catálogo y de implementación.

IMPORTANTE: adaptar obtener_conexion() al módulo de conexión real del plugin.
"""

import os
import re
import math
import unicodedata
from collections import OrderedDict

from qgis.PyQt import uic, QtWidgets
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox


FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "genera_scriptSQL_dialog_base.ui")
)


# -----------------------------------------------------------------------------
# CONEXIÓN
# -----------------------------------------------------------------------------
def obtener_conexion():
    """Devuelve una conexión psycopg2 usando la conexión ya existente del plugin.

    CAMBIA únicamente la importación siguiente si tu función real está en otro
    módulo o tiene otro nombre. La función debe devolver una conexión abierta.
    """
    from .conexion import obtener_conexion as conectar
    return conectar()


# -----------------------------------------------------------------------------
# CONSULTAS A LAS VISTAS
# -----------------------------------------------------------------------------
def leer_objetos(conn):
    sql = """
        SELECT DISTINCT objeto
        FROM cog_w.cog_cat_valores_vw
        WHERE objeto IS NOT NULL
        ORDER BY objeto;
    """
    with conn.cursor() as cur:
        cur.execute(sql)
        return [fila[0] for fila in cur.fetchall() if fila[0]]


def leer_catalogo_objeto(conn, objeto):
    sql = """
        SELECT objeto, geometria, cod_atributo, atributo, nombre_campo,
               tipo_dato, longitud, existencia_catalogos, cod_valor,
               valor, restriccion
        FROM cog_w.cog_cat_valores_vw
        WHERE objeto = %s
        ORDER BY cod_atributo, cod_valor;
    """
    with conn.cursor() as cur:
        cur.execute(sql, (objeto,))
        columnas = [d[0] for d in cur.description]
        registros = cur.fetchall()
    return columnas, registros


def leer_atributos_implementacion(conn, objeto):
    sql = """
        SELECT objeto, geometria, cod_atr_imp, nombre_campo, tipo_dato,
               longitud, cod_valor_imp, valor
        FROM cog_w.atributo_implementacion_vw
        WHERE objeto = %s
        ORDER BY cod_atr_imp ASC, cod_valor_imp ASC;
    """
    with conn.cursor() as cur:
        cur.execute(sql, (objeto,))
        columnas = [d[0] for d in cur.description]
        registros = cur.fetchall()
    return columnas, registros


def ejecutar_lectura(funcion, *args):
    """Abre la conexión, ejecuta una lectura y siempre cierra la conexión.

    Los resultados devueltos por las funciones de lectura son listas en memoria,
    por lo que no necesitan mantener abierta la conexión.
    """
    conn = None
    try:
        conn = obtener_conexion()
        if conn is None or getattr(conn, "closed", 0):
            raise RuntimeError("La función de conexión no devolvió una conexión abierta.")
        return funcion(conn, *args)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


# -----------------------------------------------------------------------------
# UTILIDADES PARA IDENTIFICADORES Y TIPOS SQL
# -----------------------------------------------------------------------------
def identificador_sql(nombre):
    """Cita un identificador PostgreSQL de forma segura."""
    return '"' + str(nombre).replace('"', '""') + '"'


def literal_sql(valor):
    """Cita un valor de texto SQL escapando apóstrofes."""
    return "'" + str(valor).replace("'", "''") + "'"


def texto(valor):
    return "" if valor is None else str(valor).strip()


def normalizar_nombre(texto_nombre):
    valor = unicodedata.normalize("NFD", texto(texto_nombre).lower())
    valor = "".join(c for c in valor if unicodedata.category(c) != "Mn")
    valor = re.sub(r"[^a-z0-9_]+", "_", valor).strip("_")
    if not valor:
        valor = "objeto"
    if valor[0].isdigit():
        valor = "obj_" + valor
    # PostgreSQL limita los identificadores a 63 bytes; aquí se limita por
    # caracteres ASCII, suficiente después de la normalización anterior.
    return valor[:55]


def convertir_longitud(longitud):
    if longitud in (None, "", 0, "0"):
        return None
    if isinstance(longitud, bool):
        return None
    if isinstance(longitud, int):
        return str(longitud) if longitud > 0 else None
    if isinstance(longitud, float):
        if not math.isfinite(longitud) or longitud <= 0:
            return None
        if longitud.is_integer():
            return str(int(longitud))
        return str(longitud).replace(".", ",")
    valor = texto(longitud).replace(" ", "")
    if not re.fullmatch(r"\d+(?:[,.]\d+)?", valor):
        return None
    return valor.replace(".", ",")


def obtener_tipo_sql(tipo_dato, longitud=None, nombre_campo=None):
    tipo_original = texto(tipo_dato)
    tipo = tipo_original.lower()

    mapa = {
        "uuid": "character varying",
        "fecha": "date",
        "date": "date",
        "numérico": "numeric",
        "numerico": "numeric",
        "numeric": "numeric",
        "carácter": "character varying",
        "caracter": "character varying",
        "character varying": "character varying",
        "varchar": "character varying",
        "texto": "text",
        "text": "text",
        "entero": "integer",
        "integer": "integer",
        "int": "integer",
        "smallint": "smallint",
        "bigint": "bigint",
        "boolean": "boolean",
        "booleano": "boolean",
        "real": "real",
        "double precision": "double precision",
        "geometry - point": "character varying",
    }
    tipo_sql = mapa.get(tipo)

    if tipo_sql is None:
        # Se permiten tipos PostgreSQL conocidos si la vista ya los devuelve.
        tipos_directos = {
            "timestamp", "timestamp without time zone",
            "timestamp with time zone", "time", "time without time zone",
            "time with time zone", "json", "jsonb",
        }
        if tipo in tipos_directos:
            tipo_sql = tipo
        else:
            raise ValueError(
                "Tipo de dato no reconocido para el campo "
                f"{nombre_campo or '(sin nombre)'}: {tipo_original!r}"
            )

    if texto(nombre_campo).lower() == "coord_acceso":
        return "character varying(255)"

    if tipo_sql in {
        "date", "text", "integer", "smallint", "bigint", "boolean",
        "real", "double precision", "timestamp", "timestamp without time zone",
        "timestamp with time zone", "time", "time without time zone",
        "time with time zone", "json", "jsonb",
    }:
        return tipo_sql

    long_sql = convertir_longitud(longitud)
    if long_sql:
        if tipo_sql == "numeric":
            partes = long_sql.split(",")
            return f"numeric({partes[0]},{partes[1]})" if len(partes) == 2 else f"numeric({partes[0]},0)"
        if tipo_sql == "character varying":
            return f"character varying({long_sql})"
    return tipo_sql


# -----------------------------------------------------------------------------
# COMBINACIÓN DE ATRIBUTOS
# -----------------------------------------------------------------------------
def agregar_unico(lista, valor):
    if valor is None:
        return
    valor = texto(valor)
    if valor and valor not in lista:
        lista.append(valor)


def normalizar_geometria(valor):
    """Normaliza nombres de geometría para comparar valores de las vistas."""
    valor = texto(valor).lower()
    valor = unicodedata.normalize("NFD", valor)
    valor = "".join(c for c in valor if unicodedata.category(c) != "Mn")
    valor = re.sub(r"\s+", " ", valor).strip()

    equivalencias = {
        "punto": "punto", "point": "punto",
        "multipunto": "punto", "multipoint": "punto",
        "linea": "linea", "linestring": "linea",
        "line string": "linea", "multilinea": "linea",
        "multilinestring": "linea",
        "poligono": "poligono", "polygon": "poligono",
        "multipoligono": "poligono", "multipolygon": "poligono",
    }
    return equivalencias.get(valor, valor)


def geometria_coincide(geometria_registro, geometria_objetivo):
    """Comprueba si una fila de implementación corresponde a una geometría."""
    objetivo = normalizar_geometria(geometria_objetivo)
    if not objetivo or geometria_registro is None:
        return False

    valores = [
        normalizar_geometria(parte)
        for parte in str(geometria_registro).split("/")
        if texto(parte)
    ]
    return objetivo in valores


def construir_atributos(registros_catalogo, registros_implementacion,
                        incluir_catalogo=True, incluir_implementacion=True,
                        geometria_objetivo=None):
    """Combina atributos comunes del catálogo con implementación específica
    de la geometría de la tabla SQL que se está generando.
    """
    atributos = OrderedDict()

    if incluir_catalogo:
        for fila in registros_catalogo:
            (objeto, geometria, cod_atributo, atributo, nombre_campo,
             tipo_dato, longitud, existencia_catalogos, cod_valor,
             valor, restriccion) = fila

            nombre = texto(nombre_campo)
            if not nombre or nombre.lower() == "geom":
                continue
            clave = nombre.lower()

            if clave not in atributos:
                atributos[clave] = {
                    "nombre": nombre,
                    "tipo_dato": tipo_dato,
                    "longitud": longitud,
                    "origen": "catalogo",
                    "dominio": [],
                    "restricciones": [],
                }

            dato = atributos[clave]
            # Un valor vacío o sin código no se considera miembro del dominio.
            if cod_valor is not None and valor is not None:
                agregar_unico(dato["dominio"], valor)
            if restriccion is not None:
                agregar_unico(dato["restricciones"], restriccion)

    if incluir_implementacion:
        for fila in registros_implementacion:
            (objeto, geometria, cod_atr_imp, nombre_campo, tipo_dato,
             longitud, cod_valor_imp, valor) = fila

            # Los atributos de implementación solo se incorporan a la tabla
            # de la geometría indicada en atributo_implementacion_vw.
            if geometria_objetivo is not None and not geometria_coincide(
                geometria, geometria_objetivo
            ):
                continue

            nombre = texto(nombre_campo)
            if not nombre or nombre.lower() == "geom":
                continue
            clave = nombre.lower()

            if clave not in atributos:
                atributos[clave] = {
                    "nombre": nombre,
                    "tipo_dato": tipo_dato,
                    "longitud": longitud,
                    "origen": "implementacion",
                    "dominio": [],
                    "restricciones": [],
                }

            dato = atributos[clave]
            if cod_valor_imp is not None and valor is not None:
                agregar_unico(dato["dominio"], valor)

    return list(atributos.values())


def obtener_geometrias(registros_catalogo, registros_implementacion,
                       incluir_catalogo=True, incluir_implementacion=True):
    geometrias = set()
    filas = []
    if incluir_catalogo:
        filas.extend(registros_catalogo)
    if incluir_implementacion:
        filas.extend(registros_implementacion)

    for fila in filas:
        geometria = fila[1]
        if geometria:
            for item in str(geometria).split("/"):
                item = texto(item)
                if item:
                    geometrias.add(item)
    return sorted(geometrias, key=str.casefold)


# -----------------------------------------------------------------------------
# RESTRICCIONES CHECK
# -----------------------------------------------------------------------------
def expresion_rango(campo_sql, restriccion):
    """Interpreta solo formatos de rango numérico explícitos y reconocibles."""
    r = re.sub(r"^\s*valor\s*", "", texto(restriccion), flags=re.IGNORECASE).strip()
    numero = r"-?\d+(?:[.,]\d+)?"

    # Intervalo: mínimo <= valor <= máximo
    m = re.fullmatch(rf"({numero})\s*≤\s*.*?\s*≤\s*({numero})", r)
    if m:
        a, b = (m.group(1).replace(",", "."), m.group(2).replace(",", "."))
        return f"({campo_sql} >= {a}::numeric AND {campo_sql} <= {b}::numeric)"

    # Límite simple: ≤ 100, ≥ 0, < 10, > 2
    m = re.fullmatch(rf"(≤|≥|<|>)\s*({numero})", r)
    if m:
        operador = {"≤": "<=", "≥": ">="}.get(m.group(1), m.group(1))
        n = m.group(2).replace(",", ".")
        return f"{campo_sql} {operador} {n}::numeric"

    # Expresión que contiene el campo, por ejemplo: 0 <= valor <= 100.
    m = re.fullmatch(rf"({numero})\s*(<=|<|≥|>=|≤)\s*.*?\s*(<=|<|≥|>=|≤)\s*({numero})", r)
    if m:
        a, op1, op2, b = m.groups()
        op1 = {"≤": "<=", "≥": ">="}.get(op1, op1)
        op2 = {"≤": "<=", "≥": ">="}.get(op2, op2)
        a, b = a.replace(",", "."), b.replace(",", ".")
        # La expresión solo es un intervalo convencional si ambas relaciones
        # van en la dirección esperada.
        if op1 in ("<", "<=") and op2 in ("<", "<="):
            operador_inferior = ">=" if op1 == "<=" else ">"
            operador_superior = "<=" if op2 == "<=" else "<"
            return (
                f"({campo_sql} {operador_inferior} {a}::numeric "
                f"AND {campo_sql} {operador_superior} {b}::numeric)"
            )

    return None


def construir_checks(atributo, tabla, contador):
    checks = []
    campo = identificador_sql(atributo["nombre"])
    nombre_base = normalizar_nombre(atributo["nombre"])

    if atributo["nombre"].strip().lower() == "numero_ver":
        nombre_objeto = normalizar_nombre(tabla.rsplit("_", 1)[0])
        nombre_check = f"{nombre_objeto}_numero_ver_dom_1"[:63]
        checks.append(
            f"    CONSTRAINT {identificador_sql(nombre_check)} "
            f"CHECK ({campo} >= 1)"
        )
        return checks, contador

    # Se conservan exclusiones de la lógica original.
    campos_sin_check = {
        "geoid", "fecha_ver", "nom_cono", "geom", "coord_acceso",
        "nom_geo", "fecha",
    }
    if atributo["nombre"].lower() in campos_sin_check:
        return checks, contador

    dominio = atributo["dominio"]
    normalizaciones = {
        "ninguno (n)": "N",
        "solo aplica": "S/A",
        "solo aplica (s/a)": "S/A",
        "no disponible (n/d)": "N/D",
        "no aplicable (n/a)": "N/A",
    }
    dominio_normalizado = []
    for valor in dominio:
        v = normalizaciones.get(valor.lower(), valor)
        if v.lower().startswith(("consultar", "indeter")):
            # Si existe un valor de catálogo que requiere consulta o es
            # indeterminado, no se impone un dominio cerrado al campo.
            dominio_normalizado = []
            break
        agregar_unico(dominio_normalizado, v)

    if dominio_normalizado:
        valores = ", ".join(literal_sql(v) for v in sorted(set(dominio_normalizado)))
        nombre_check = normalizar_nombre(f"{tabla}_{nombre_base}_dom_{contador}")[:63]
        checks.append(
            f"    CONSTRAINT {identificador_sql(nombre_check)} "
            f"CHECK ({campo}::text = ANY (ARRAY[{valores}]::text[]))"
        )
        contador += 1

    for restriccion in atributo["restricciones"]:
        expresion = expresion_rango(campo, restriccion)
        if not expresion:
            continue
        nombre_check = normalizar_nombre(f"{tabla}_{nombre_base}_rango_{contador}")[:63]
        checks.append(
            f"    CONSTRAINT {identificador_sql(nombre_check)} CHECK ({expresion})"
        )
        contador += 1

    return checks, contador


# -----------------------------------------------------------------------------
# DIÁLOGO PRINCIPAL
# -----------------------------------------------------------------------------
class catSQLDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        super(catSQLDialog, self).__init__(parent)
        self.setupUi(self)

        self._objetos = []

        self.pushButton.clicked.connect(self.generar_sql)
        self.buttonRecargarObjetos.clicked.connect(self.cargar_objetos)
        self.buttonCopiarSQL.clicked.connect(self.copiar_sql)
        self.buttonLimpiarSQL.clicked.connect(self.limpiar_sql)
        self.buttonGuardarSQL.clicked.connect(self.guardar_sql)
        self.buttonCerrar.clicked.connect(self.close)
        self.lineEditBuscarObjeto.textChanged.connect(self.filtrar_objetos)

        self.cargar_objetos()

    def establecer_estado(self, mensaje):
        if hasattr(self, "labelEstado"):
            self.labelEstado.setText(mensaje)

    def cargar_objetos(self):
        seleccion_anterior = self.comboBox.currentText()
        self.buttonRecargarObjetos.setEnabled(False)
        self.establecer_estado("Conectando con PostgreSQL y cargando objetos...")
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self._objetos = ejecutar_lectura(leer_objetos)
            self.filtrar_objetos(self.lineEditBuscarObjeto.text())
            indice = self.comboBox.findText(seleccion_anterior)
            if indice >= 0:
                self.comboBox.setCurrentIndex(indice)
            if self._objetos:
                self.establecer_estado(
                    f"{len(self._objetos)} objetos cargados. Conexión cerrada."
                )
            else:
                self.establecer_estado("La consulta no devolvió objetos.")
                QMessageBox.information(
                    self, "Sin objetos",
                    "La vista cog_w.cog_cat_valores_vw no contiene objetos disponibles."
                )
        except Exception as e:
            self._objetos = []
            self.comboBox.clear()
            self.establecer_estado("No fue posible cargar los objetos desde PostgreSQL.")
            QMessageBox.critical(
                self, "Error de conexión",
                "No fue posible cargar los objetos desde PostgreSQL.\n\n"
                f"Detalle: {e}\n\n"
                "Verifica la función obtener_conexion() en este archivo."
            )
        finally:
            self.buttonRecargarObjetos.setEnabled(True)
            QtWidgets.QApplication.restoreOverrideCursor()

    def filtrar_objetos(self, filtro):
        filtro = texto(filtro).casefold()
        seleccion = self.comboBox.currentText()
        coincidencias = [o for o in self._objetos if filtro in str(o).casefold()]

        self.comboBox.blockSignals(True)
        self.comboBox.clear()
        self.comboBox.addItems(coincidencias)
        indice = self.comboBox.findText(seleccion)
        if indice >= 0:
            self.comboBox.setCurrentIndex(indice)
        self.comboBox.blockSignals(False)

    def generar_sql(self):
        objeto = texto(self.comboBox.currentText())
        if not objeto:
            QMessageBox.warning(self, "Sin selección", "Selecciona un objeto geográfico.")
            return

        incluir_catalogo = self.checkBoxCatalogo.isChecked()
        incluir_implementacion = self.checkBoxImplementacion.isChecked()
        if not incluir_catalogo and not incluir_implementacion:
            QMessageBox.warning(
                self, "Sin fuentes seleccionadas",
                "Selecciona al menos una fuente de atributos."
            )
            return

        self.pushButton.setEnabled(False)
        self.establecer_estado(f"Consultando información de «{objeto}»...")
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # Las dos lecturas se ejecutan con conexiones independientes y se
            # cierran inmediatamente después de recuperar los datos.
            if incluir_catalogo:
                _, registros_catalogo = ejecutar_lectura(leer_catalogo_objeto, objeto)
            else:
                registros_catalogo = []

            if incluir_implementacion:
                _, registros_imp = ejecutar_lectura(leer_atributos_implementacion, objeto)
            else:
                registros_imp = []

            if not registros_catalogo and not registros_imp:
                raise ValueError("No hay información para el objeto seleccionado en las vistas consultadas.")

            geometrias = obtener_geometrias(
                registros_catalogo,
                registros_imp,
                incluir_catalogo,
                incluir_implementacion,
            )
            if not geometrias:
                raise ValueError("No se encontró información de geometría para el objeto.")

            sql, total_atributos = self.construir_sql(
                objeto,
                geometrias,
                registros_catalogo,
                registros_imp,
                incluir_catalogo,
                incluir_implementacion,
            )
            self.plainTextEdit.setPlainText(sql)
            self.establecer_estado(
                f"SQL generado para «{objeto}». Atributos por geometría: "
                f"{total_atributos}. Conexiones cerradas."
            )
        except Exception as e:
            self.establecer_estado("Ocurrió un error al generar el SQL.")
            QMessageBox.critical(
                self, "Error al generar SQL",
                f"No fue posible generar el script.\n\nDetalle: {e}"
            )
        finally:
            self.pushButton.setEnabled(True)
            QtWidgets.QApplication.restoreOverrideCursor()

    def construir_sql(
        self,
        objeto,
        geometrias,
        registros_catalogo,
        registros_implementacion,
        incluir_catalogo=True,
        incluir_implementacion=True,
    ):
        mapa_geometrias = {
            "punto": ("p", "Point"),
            "línea": ("l", "LineString"),
            "linea": ("l", "LineString"),
            "polígono": ("a", "Polygon"),
            "poligono": ("a", "Polygon"),
        }
        nombre_base = normalizar_nombre(objeto)
        srid = int(self.spinBoxSRID.value())
        incluir_checks = self.checkBoxChecks.isChecked()
        incluir_pk = self.checkBoxClavePrimaria.isChecked()
        incluir_insert = self.checkBoxInsert.isChecked()
        bloques = []
        total_atributos = 0

        for geometria in geometrias:
            geom_key = texto(geometria).lower()
            if geom_key not in mapa_geometrias:
                continue
            sufijo, tipo_geom = mapa_geometrias[geom_key]
            nombre_tabla = f"{nombre_base}_{sufijo}"[:55]
            tabla_sql = identificador_sql(nombre_tabla)

            # Se calcula el conjunto de atributos para cada geometría por
            # separado; así, un atributo exclusivo de Punto no aparece en
            # las tablas de Línea o Polígono.
            atributos = construir_atributos(
                registros_catalogo,
                registros_implementacion,
                incluir_catalogo=incluir_catalogo,
                incluir_implementacion=incluir_implementacion,
                geometria_objetivo=geometria,
            )
            if not atributos:
                raise ValueError(
                    f"No se encontraron atributos para la geometría «{geometria}»."
                )
            total_atributos += len(atributos)

            definiciones = []
            campos_vistos = set()
            for atributo in atributos:
                nombre = atributo["nombre"]
                if nombre.lower() in campos_vistos:
                    continue
                campos_vistos.add(nombre.lower())
                tipo_sql = obtener_tipo_sql(
                    atributo["tipo_dato"], atributo["longitud"], nombre
                )
                definiciones.append(f"    {identificador_sql(nombre)} {tipo_sql}")

            definiciones.append(f"    {identificador_sql('geom')} geometry({tipo_geom}, {srid})")

            tiene_geoid = any(a["nombre"].lower() == "geoid" for a in atributos)
            if incluir_pk and tiene_geoid:
                nombre_pk = normalizar_nombre(f"{nombre_tabla}_pk")[:63]
                definiciones.append(
                    f"    CONSTRAINT {identificador_sql(nombre_pk)} "
                    f"PRIMARY KEY ({identificador_sql('geoid')})"
                )

            if incluir_checks:
                contador = 1
                for atributo in atributos:
                    checks, contador = construir_checks(atributo, nombre_tabla, contador)
                    definiciones.extend(checks)
            definiciones.append(
                    "CONSTRAINT chk_geometria_no_vacia " "CHECK ((geom IS NOT NULL) AND (NOT ST_IsEmpty(geom)))"
                    )

            bloque = (
                f"CREATE TABLE IF NOT EXISTS {tabla_sql}\n(\n"
                + ",\n".join(definiciones)
                + "\n);\n"
            )

            if incluir_insert:
                campos_insert = [identificador_sql(a["nombre"]) for a in atributos]
                campos_insert.append(identificador_sql("geom"))
                bloque += (
                    f"\nINSERT INTO {tabla_sql} ({', '.join(campos_insert)})\n"
                    "SELECT\n"
                    "    -- Sustituir por las columnas de origen\n"
                    "FROM\n"
                    "    -- Sustituir por la tabla o consulta de origen\n"
                    ";\n"
                )

            bloques.append(bloque)

        if not bloques:
            raise ValueError("No se encontraron geometrías compatibles: Punto, Línea o Polígono.")

        return "\n".join(bloques), total_atributos

    def copiar_sql(self):
        sql = self.plainTextEdit.toPlainText()
        if not sql.strip():
            QMessageBox.information(self, "Sin SQL", "No hay SQL para copiar.")
            return
        QtWidgets.QApplication.clipboard().setText(sql)
        self.establecer_estado("SQL copiado al portapapeles.")

    def limpiar_sql(self):
        self.plainTextEdit.clear()
        self.establecer_estado("Editor SQL limpio.")

    def guardar_sql(self):
        sql = self.plainTextEdit.toPlainText()
        if not sql.strip():
            QMessageBox.information(self, "Sin SQL", "Genera el SQL antes de guardarlo.")
            return
        ruta, _ = QFileDialog.getSaveFileName(
            self,
            "Guardar script SQL",
            "estructura_objeto.sql",
            "Archivos SQL (*.sql);;Todos los archivos (*.*)",
        )
        if not ruta:
            return
        if not ruta.lower().endswith(".sql"):
            ruta += ".sql"
        try:
            with open(ruta, "w", encoding="utf-8") as archivo:
                archivo.write(sql)
            self.establecer_estado(f"Script guardado en: {ruta}")
        except OSError as e:
            QMessageBox.critical(self, "Error al guardar", str(e))
