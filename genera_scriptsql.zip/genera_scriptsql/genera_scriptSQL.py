# -*- coding: utf-8 -*-

import os

from qgis.PyQt.QtCore import QCoreApplication, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QDialog
from qgis.core import Qgis, QgsSettings

from .genera_scriptSQL_dialog import catSQLDialog


class catSQL:
    """Implementación del complemento Generador SQL geográfico."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        locale = QgsSettings().value(
            "locale/userLocale", "es_MX"
        )[0:2]

        locale_path = os.path.join(
            self.plugin_dir,
            "i18n",
            f"catSQL_{locale}.qm"
        )

        self.translator = None

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = self.tr("&GeneraScriptSQL")
        self.dialog = None

    def tr(self, message):
        """Traduce los textos del complemento."""
        return QCoreApplication.translate("catSQL", message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None
    ):
        """Agrega una acción al menú y a la barra de herramientas."""

        action = QAction(QIcon(icon_path), text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)

        if whats_this:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Registra la acción del complemento en QGIS."""

        icon_path = os.path.join(self.plugin_dir, "icon.png")

        self.add_action(
            icon_path=icon_path,
            text=self.tr("Generar Script SQL"),
            callback=self.run,
            parent=self.iface.mainWindow()
        )

    def unload(self):
        """Retira las acciones del complemento de QGIS."""

        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)

        self.actions.clear()

        if self.translator:
            QCoreApplication.removeTranslator(self.translator)

    def run(self):
        """Abre el diálogo del generador SQL."""

        self.dialog = catSQLDialog()
        self.dialog.exec_()
        self.dialog = None