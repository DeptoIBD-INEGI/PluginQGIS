
# -*- coding: utf-8 -*-
"""
Conexión fija a PostgreSQL para el plugin Generador SQL geográfico.

Este módulo utiliza exclusivamente la conexión definida en CATALOGO.
No consulta ni muestra las conexiones guardadas en QGIS.
"""

import psycopg2


CATALOGO = {
    "host": "10.153.3.33",
    "port": 5438,
    "database": "produ_pg",
    "username": "cog_w",
    "password": "C0gW",
    "sslmode": "prefer",
    "schema": "cog_w",
    "vista": "cog_cat_valores_vw",
}


def obtener_conexion(timeout=10):
    """
    Abre una conexión a la base de datos definida en CATALOGO.

    Args:
        timeout (int): segundos máximos de espera para establecer conexión.

    Returns:
        psycopg2.extensions.connection: conexión abierta. El código que la
        invoque debe cerrarla cuando termine de utilizarla.

    Raises:
        RuntimeError: si no se puede importar psycopg2.
        psycopg2.Error: si PostgreSQL rechaza la conexión o no está disponible.
    """
    parametros = {
        "host": CATALOGO["host"],
        "port": CATALOGO["port"],
        "dbname": CATALOGO["database"],
        "user": CATALOGO["username"],
        "password": CATALOGO["password"],
        "sslmode": CATALOGO["sslmode"],
        "connect_timeout": int(timeout),
        "application_name": "Generador SQL geográfico",
    }

    conexion = psycopg2.connect(**parametros)

    # El plugin consulta vistas para generar el SQL; no necesita modificar datos.
    conexion.set_session(readonly=True, autocommit=False)

    return conexion
