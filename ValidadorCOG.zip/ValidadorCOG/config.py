# ==========================================
# BASE DE DATOS DEL CATÁLOGO
# ==========================================

CATALOGO = {

    "host": "10.153.3.33",

    "port": 5438,

    "database": "produ_pg",

    "username": "cog_w",

    "password": "C0gW",

    "sslmode": "prefer",

    "schema": "cog_w",

    "vista": "cog_cat_valores_vw"

}