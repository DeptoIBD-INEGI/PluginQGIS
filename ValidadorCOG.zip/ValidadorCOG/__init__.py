def classFactory(iface):
    try:
        from .validador import ValidadorCOG
        print("Importó validador correctamente")
        return ValidadorCOG(iface)

    except Exception as e:
        import traceback
        print(traceback.format_exc())
        raise