from qgis.PyQt.QtWidgets import QAction, QMessageBox
from .dialog import ValidadorDialog
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction


class ValidadorCOG:

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None
        self.conn_usuario = None
        self.conn_catalogo = None
        print("Constructor del plugin")

    def initGui(self):
        print("Entró a initGui")

        self.action = QAction("Validador COG", self.iface.mainWindow())

        self.action.triggered.connect(self.run)

        self.iface.addPluginToMenu(
            "&Validador COG",
            self.action
        )

        self.iface.addToolBarIcon(self.action)

        print("Acción agregada")

    def unload(self):
        print("Unload")

    def run(self):

        #if self.dialog is None:
        self.dialog = ValidadorDialog()

        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()