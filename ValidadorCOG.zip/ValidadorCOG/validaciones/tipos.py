TIPOS_CATALOGO = {

    "Carácter": "character varying",

    "Fecha": "date",

    "Geometry": "geometry",

    "Geometry - Point": "character varying",

    "Numérico": "numeric",

    "Real": "real",

    "timestamp": "date",

    "uuid": "character varying"

}


def obtener_tipo_catalogo(tipo):

    return TIPOS_CATALOGO.get(
        tipo,
        tipo
    )