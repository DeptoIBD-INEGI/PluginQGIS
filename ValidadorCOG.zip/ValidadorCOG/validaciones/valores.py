import re


def es_regla(texto):
    """
    Determina si un valor del catálogo representa
    una regla de validación o un valor literal.
    """

    if texto is None:
        return False

    texto = str(texto).strip()

    if texto == "":
        return False

    texto_lower = texto.lower()

    patrones = [

        "valor",

        "del ",

        "≥",

        "≤",

        ">",

        "<"

    ]

    for patron in patrones:

        if patron in texto_lower:

            return True

    # Intervalos tipo 001-999
    if re.search(r"\d+\s*-\s*\d+", texto):

        return True

    return False

def es_literal(texto):
    """
    Determina si el valor corresponde a
    un valor permitido literal.
    """

    return not es_regla(texto)

def validar_literal(valores_bd, valores_catalogo):
    """
    Valida que todos los valores existentes en la Feature Class
    pertenezcan al catálogo.

    Parameters
    ----------
    valores_bd : list

    valores_catalogo : list

    Returns
    -------
    tuple

        (True, [])

        (False, [lista de valores inválidos])
    """

    # Convertimos el catálogo en un set para acelerar la búsqueda
    permitidos = set()

    permite_null = False

    for valor in valores_catalogo:

        if valor is None:
            continue

        valor = str(valor).strip()

        if valor.upper() == "NULL":

            permite_null = True

        else:

            permitidos.add(valor)

    invalidos = set()

    for valor in valores_bd:

        if valor is None:

            if not permite_null:

                invalidos.add("NULL")

            continue

        valor = str(valor).strip()

        if valor not in permitidos:

            invalidos.add(str(valor))

    return len(invalidos) == 0, sorted(invalidos)


def validar_intervalo(valores_bd, reglas_catalogo):
    """
    Valida intervalos del tipo

        001-999
        01-32
        0001-9999

    Retorna

        (True, [])

        (False, [lista de valores inválidos])
    """

    minimo = None
    maximo = None
    permite_null = False

    for regla in reglas_catalogo:

        if regla is None:
            continue

        regla = regla.strip()

        if regla.upper() == "NULL":

            permite_null = True
            continue

        m = re.match(r"(\d+)\s*-\s*(\d+)", regla)

        if m:

            minimo = int(m.group(1))
            maximo = int(m.group(2))

            break

    invalidos = set()

    for valor in valores_bd:

        if valor is None:

            if not permite_null:

                invalidos.add("NULL")

            continue

        try:

            numero = int(valor)

        except:

            invalidos.add(str(valor))

            continue

        if numero < minimo or numero > maximo:

            invalidos.add(str(valor))

    return len(invalidos) == 0, sorted(invalidos)


def validar_comparacion(valores_bd, reglas_catalogo):
    """
    Valida reglas de comparación.

    Ejemplos:

        Valor ≥ 1

        Valor > 0

        0 ≤ Valor ≤ 9999

        -20 ≤ valor ≤ 50
    """

    permite_null = False

    minimo = None
    maximo = None

    op_min = None
    op_max = None

    for regla in reglas_catalogo:

        if regla is None:
            continue

        regla = regla.strip()

        if regla.upper() == "NULL":

            permite_null = True
            continue

        regla = regla.replace("˂", "<")
        regla = regla.replace("˃", ">")

        #
        # Valor >= 1
        #
        m = re.search(
            r"valor\s*(>=|>|≤|<=|≥|<)\s*(-?\d+(\.\d+)?)",
            regla,
            re.IGNORECASE
        )

        if m:

            op_min = m.group(1)

            minimo = float(m.group(2))

            continue

        #
        # 0 <= valor <= 9999
        #
        m = re.search(
            r"(-?\d+(\.\d+)?)\s*(<=|≤|<)\s*valor\s*(<=|≤|<)\s*(-?\d+(\.\d+)?)",
            regla,
            re.IGNORECASE
        )

        if m:

            minimo = float(m.group(1))

            op_min = m.group(3)

            op_max = m.group(4)

            maximo = float(m.group(5))

            continue

    invalidos = set()

    for valor in valores_bd:

        if valor is None:

            if not permite_null:

                invalidos.add("NULL")

            continue

        try:

            numero = float(valor)

        except:

            invalidos.add(str(valor))

            continue

        valido = True

        #
        # límite inferior
        #

        if minimo is not None:

            if op_min in ("≥", ">="):

                if numero < minimo:
                    valido = False

            elif op_min in (">",):

                if numero <= minimo:
                    valido = False

            elif op_min in ("≤", "<="):

                if numero < minimo:
                    valido = False

            elif op_min == "<":

                if numero <= minimo:
                    valido = False

        #
        # límite superior
        #

        if maximo is not None:

            if op_max in ("≤", "<="):

                if numero > maximo:
                    valido = False

            elif op_max == "<":

                if numero >= maximo:
                    valido = False

        if not valido:

            invalidos.add(str(valor))

    return len(invalidos) == 0, sorted(invalidos)

def validar_compuesta(valores_bd, reglas_catalogo):
    """
    Valida reglas compuestas.

    Ejemplo:

        Número: 001-999
        Dígito verificador: 0-9 o A
        NULL
    """

    permite_null = False

    intervalo = None

    validar_digito = False

    # Analizar reglas del catálogo
    for regla in reglas_catalogo:

        if regla is None:
            continue

        regla = regla.strip()

        if regla.upper() == "NULL":

            permite_null = True

            continue

        if regla.lower().startswith("número"):

            intervalo = regla.split(":", 1)[1].strip()

        elif "dígito" in regla.lower() or "digito" in regla.lower():

            validar_digito = True
        
        elif regla.lower().startswith("del "):
            partes = regla.split("/")
            intervalo = partes[0].replace("Del", "").replace("del", "").replace("al", "-").strip()
            validar_digito = True


    invalidos = set()

    for valor in valores_bd:

        if valor is None:

            if not permite_null:

                invalidos.add("NULL")

            continue

        valor = str(valor).strip()

        if len(valor) < 2:

            invalidos.add(valor)

            continue

        numero = valor[:-1]

        digito = valor[-1]

        #
        # Validar intervalo
        #

        ok, _ = validar_intervalo(

            [numero],

            [intervalo]

        )

        if not ok:

            invalidos.add(valor)

            continue

        #
        # Validar dígito
        #

        if validar_digito:

            if not (digito.isdigit() or digito.upper() == "A"):

                invalidos.add(valor)

    return len(invalidos) == 0, sorted(invalidos)

def tipo_regla(valores_catalogo):
    """
    Clasifica el tipo de validación de un atributo.

    Retorna:

        LITERAL
        INTERVALO
        COMPARACION
        COMPUESTA
        ESTRUCTURA
        DESCONOCIDA
    """

    reglas = [v.strip() for v in valores_catalogo if v is not None]

    texto = " ".join(reglas).lower()

    # Reglas compuestas
    if any("dígito" in r.lower() or "digito" in r.lower()
           for r in reglas):

        return "COMPUESTA"

    # Claves geoestadísticas
    if any(palabra in texto
    for palabra in(
        "agee",
        "agem",
        #"localidad",
        "ageb",
        #"infr"
    )
    ):
        return "ESTRUCTURA"

    # Comparaciones
    if any(x in texto for x in ["≥", "≤", ">", "<"]):

        return "COMPARACION"

    # Intervalos
    if any(re.search(r"\d+\s*-\s*\d+", r)
           for r in reglas):

        return "INTERVALO"

    # Si ninguna regla coincide,
    # son valores literales
    if not any(es_regla(r) for r in reglas):

        return "LITERAL"

    if any( "del " in r.lower() and "0 a 9" in r.lower() for r in reglas):
        return "COMPUESTA"

    return "DESCONOCIDA"

def validar_estructura(valores_bd, reglas_catalogo):
    """
    Valida la estructura de cvegeo.

    Formatos permitidos

        9 caracteres
            AA MMM LLLL

        16 caracteres
            AA MMM LLLL AAA D MMM
    """

    permite_null = any(
        r is not None and str(r).upper() == "NULL"
        for r in reglas_catalogo
    )

    invalidos = set()

    for valor in valores_bd:

        if valor is None:

            if not permite_null:
                invalidos.add("NULL")

            continue

        valor = str(valor).strip()

        #
        # LOCALIDAD
        #

        if len(valor) == 9:

            agee = valor[0:2]

            agem = valor[2:5]

            localidad = valor[5:9]

            ok, _ = validar_intervalo([agee], ["01-32"])

            if not ok:
                invalidos.add(valor)
                continue

            ok, _ = validar_intervalo([agem], ["001-999"])

            if not ok:
                invalidos.add(valor)
                continue

            ok, _ = validar_intervalo([localidad], ["0001-9999"])

            if not ok:
                invalidos.add(valor)

            continue

        #
        # MANZANA
        #

        if len(valor) == 16:

            agee = valor[0:2]

            agem = valor[2:5]

            localidad = valor[5:9]

            ageb = valor[9:12]

            digito = valor[12]

            manzana = valor[13:16]

            ok, _ = validar_intervalo([agee], ["01-32"])

            if not ok:
                invalidos.add(valor)
                continue

            ok, _ = validar_intervalo([agem], ["001-999"])

            if not ok:
                invalidos.add(valor)
                continue

            ok, _ = validar_intervalo([localidad], ["0001-9999"])

            if not ok:
                invalidos.add(valor)
                continue

            ok, _ = validar_intervalo([ageb], ["001-999"])

            if not ok:
                invalidos.add(valor)
                continue

            #
            # Dígito
            #

            if not (digito.isdigit() or digito.upper() == "A"):

                invalidos.add(valor)

                continue

            ok, _ = validar_intervalo([manzana], ["001-999"])

            if not ok:
                invalidos.add(valor)

            continue

        #
        # Longitud distinta
        #

        invalidos.add(valor)

    return len(invalidos) == 0, sorted(invalidos)
