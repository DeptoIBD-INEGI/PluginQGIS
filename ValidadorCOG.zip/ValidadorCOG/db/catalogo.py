import psycopg2
import re
import unicodedata


def obtener_objetos_catalogo(conn):
    """
    Obtiene todos los objetos registrados en el catálogo.

    Parameters
    ----------
    conn : psycopg2.connection

    Returns
    -------
    list[str]
        Lista con los nombres de los objetos.
    """

    sql = """
        SELECT DISTINCT objeto
        FROM cog_w.cog_cat_valores_vw
        ORDER BY objeto;
    """

    with conn.cursor() as cur:

        cur.execute(sql)

        return [fila[0] for fila in cur.fetchall()]

def leer_catalogo_objeto(conn, objeto):
    """
    Obtiene toda la información del objeto desde
    cog_w.cog_cat_valores_vw.
    """

    sql = """
        SELECT
            objeto,
            geometria,
            cod_atributo,
            atributo,
            nombre_campo,
            tipo_dato,
            longitud,
            existencia_catalogos,
            cod_valor,
            valor,
            restriccion
        FROM
            cog_w.cog_cat_valores_vw
        WHERE
            objeto=%s
        ORDER BY
            cod_atributo,
            cod_valor;
    """

    with conn.cursor() as cur:

        cur.execute(sql, (objeto,))

        columnas = [d[0] for d in cur.description]

        registros = cur.fetchall()

    return columnas, registros

def procesar_catalogo(registros):
    """
    Convierte las filas del catálogo en un diccionario por campo.

    Retorna:

    {
        "nombre_campo": {
            "atributo": ...,
            "tipo_dato": ...,
            "longitud": ...,
            "restriccion": True/False,
            "existencia_catalogos": True/False,
            "valores": [...]
        }
    }
    """

    catalogo = {}

    for fila in registros:

        nombre_campo = fila[4].strip().lower()
        #self.txtLog.appendPlainText(repr(nombre_campo))

        if nombre_campo not in catalogo:

            catalogo[nombre_campo] = {

                "objeto": fila[0],

                "geometria": fila[1],

                "cod_atributo": fila[2],

                "atributo": fila[3],

                "tipo_dato": fila[5],

                "longitud": fila[6],

                "existencia_catalogos": fila[7],

                "restriccion": fila[10],

                "valores": []

            }

        if fila[9] is not None:

            catalogo[nombre_campo]["valores"].append(fila[9])

    return catalogo