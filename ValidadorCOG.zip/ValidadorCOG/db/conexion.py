from qgis.PyQt.QtCore import QSettings
import psycopg2

SSL_MAP = {
    "SslDisable": "disable",
    "SslAllow": "allow",
    "SslPrefer": "prefer",
    "SslRequire": "require",
    "SslVerifyCa": "verify-ca",
    "SslVerifyFull": "verify-full"
}

def conectar(datos):

    sslmode = SSL_MAP.get(
        datos.get("sslmode"),
        "prefer"
    )

    return psycopg2.connect(
        host=datos["host"],
        port=datos["port"],
        dbname=datos["database"],
        user=datos["username"],
        password=datos["password"],
        sslmode=sslmode
    )


def obtener_conexiones():
    """
    Obtiene las conexiones PostgreSQL registradas en QGIS.

    Returns
    -------
    list
        Lista ordenada con los nombres de las conexiones.
    """

    settings = QSettings()

    settings.beginGroup("PostgreSQL/connections")

    conexiones = settings.childGroups()

    settings.endGroup()

    conexiones.sort()

    return conexiones

def obtener_parametros(nombre):

    settings = QSettings()

    grupo = f"PostgreSQL/connections/{nombre}"

    settings.beginGroup(grupo)

    datos = {

        "host": settings.value("host"),

        "port": settings.value("port"),

        "database": settings.value("database"),

        "username": settings.value("username"),

        "password": settings.value("password"),

        "sslmode": settings.value("sslmode"),

        "service": settings.value("service")

    }

    settings.endGroup()

    return datos

def obtener_featureclass(conn, esquema):
    """
    Devuelve las Feature Class del esquema indicado.
    """

    sql = """
        SELECT
            f_table_name
        FROM
            geometry_columns
        WHERE
            f_table_schema = %s
        ORDER BY
            f_table_name;
    """
    
    with conn.cursor() as cur:

        cur.execute(sql, (esquema,))

        return [fila[0] for fila in cur.fetchall()]

