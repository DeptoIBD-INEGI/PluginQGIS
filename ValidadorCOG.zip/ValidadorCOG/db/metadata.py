import re 
from psycopg2 import sql
import psycopg2

GEOMETRIAS = {

    "Punto": "Point",

    "Línea": "LineString",

    "Linea": "LineString",

    "Polígono": "Polygon",

    "Poligono": "Polygon",

    "Multipunto": "MultiPoint",

    "Multilínea": "MultiLineString",

    "Multilinea": "MultiLineString",

    "Multipolígono": "MultiPolygon",

    "Multipoligono": "MultiPolygon"

}


TIPOS = {

    "Carácter": "character varying",

    "Fecha": "date",

    "Geometry - Point": "character varying",

    "Numérico": "numeric",

    "Real": "real",

    "timestamp": "date",

    "uuid": "character varying"

}

def obtener_campos(conn, esquema, tabla):
    """
    Obtiene la estructura física de una tabla.
    """

    sql = """
    SELECT

        a.attname,

        pg_catalog.format_type(
            a.atttypid,
            a.atttypmod
        ) AS tipo,

        a.attnotnull,

        col.character_maximum_length,

        col.numeric_precision,

        col.numeric_scale

    FROM pg_attribute a

    JOIN pg_class c
        ON a.attrelid = c.oid

    JOIN pg_namespace n
        ON c.relnamespace = n.oid

    LEFT JOIN information_schema.columns col
        ON col.table_schema = n.nspname
        AND col.table_name = c.relname
        AND col.column_name = a.attname

    WHERE

        n.nspname = %s

        AND c.relname = %s

        AND a.attnum > 0

        AND NOT a.attisdropped

    ORDER BY

        a.attnum;
    """

    with conn.cursor() as cur:

        cur.execute(sql, (esquema, tabla))

        campos = {}

        for fila in cur.fetchall():

            tipo_completo = fila[1]

            tipo_base = tipo_completo

            longitud = fila[3]

            precision = fila[4]

            escala = fila[5]

            geometria = None

            srid = None

            # character varying(25)
            m = re.match(r'([^(]+)\((\d+)\)$', tipo_completo)

            if m:

                tipo_base = m.group(1).strip()

                longitud = int(m.group(2))

            # numeric(8,2)
            m = re.match(r'([^(]+)\((\d+),(\d+)\)$', tipo_completo)

            if m:

                tipo_base = m.group(1).strip()

                precision = int(m.group(2))

                escala = int(m.group(3))

            # geometry(Polygon,6372)
            m = re.match(r'geometry\(([^,]+),\s*(\d+)\)', tipo_completo)

            if m:

                tipo_base = "geometry"

                geometria = m.group(1)

                srid = int(m.group(2))

            campos[fila[0].strip().lower()] = {

        "tipo_base": tipo_base,

        "tipo_completo": tipo_completo,

        "longitud": longitud,

        "precision": precision,

        "escala": escala,

        "geometria": geometria,

        "srid": srid,

        "not_null": fila[2]

            }

    return campos

def tipo_catalogo_postgres(tipo_catalogo):

    return TIPOS.get(
        tipo_catalogo,
        tipo_catalogo
    )

def obtener_valores_distintos(conn, esquema, tabla, campo):
    """
    Obtiene los valores distintos existentes en un campo.

    Retorna
    -------
    list
        Lista de valores distintos encontrados.
    """
    try: 

        consulta = sql.SQL("""
        SELECT DISTINCT {campo}
        FROM {esquema}.{tabla}
        ORDER BY 1
    """).format(

        campo=sql.Identifier(campo),

        esquema=sql.Identifier(esquema),

        tabla=sql.Identifier(tabla)
        )

        with conn.cursor() as cur:

            cur.execute(consulta)

            return [fila[0] for fila in cur.fetchall()]

    except psycopg2.errors.UndefinedColumn:

        conn.rollback()
        return []


        