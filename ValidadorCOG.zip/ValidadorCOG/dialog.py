from qgis.PyQt.QtWidgets import QDialog
from qgis.PyQt.QtWidgets import QTableWidgetItem
from qgis.PyQt import uic
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QHeaderView
from qgis.PyQt.QtWidgets import QMessageBox
from .db.conexion import obtener_conexiones
from .db.conexion import obtener_parametros
from .db.conexion import conectar
from .db.conexion import obtener_featureclass
from .config import CATALOGO
from .db.catalogo import obtener_objetos_catalogo, leer_catalogo_objeto, procesar_catalogo, leer_atributos_implementacion
from .db.metadata import obtener_campos, obtener_valores_distintos
from .validaciones.tipos import obtener_tipo_catalogo
from .validaciones.valores import es_regla, tipo_regla, validar_literal, validar_intervalo, validar_comparacion, validar_compuesta, validar_estructura
import os
import traceback
from qgis.PyQt.QtWidgets import QApplication

UI_FILE = os.path.join(
    os.path.dirname(__file__),
    "gui",
    "ValidadorCOG_Comercial.ui"
)
CAMPOS_SIN_VALIDAR_VALORES = {
    "geoid",
    "fecha_ver",
    "geom",
    "latitud",
    "longitud",
    "altitud",
    "cvegeo",
    "coord_acceso",
    #"nom_cono",
    "nom_geo"
}


class ValidadorDialog(QDialog):

    def __init__(self):

        super().__init__()

        uic.loadUi(UI_FILE, self)

        self.conn_usuario = None
        self.conn_catalogo = None

        self.inicializar()
    
    def inicializar(self):
    
        self.cargar_conexiones()
        self.btnCerrar.clicked.connect(self.close)

        self.cmbConexiones.currentTextChanged.connect(
        self.cambio_conexion
        )
        self.btnConectar.clicked.connect(self.conectar_bd)


        self.btnValidar.clicked.connect(
            self.validar
        )
        self.tblResultados.setWordWrap(True)

    def cargar_conexiones(self):

        self.cmbConexiones.clear()

        conexiones = obtener_conexiones()

        self.cmbConexiones.addItems(conexiones)

    def cambio_conexion(self):

        nombre = self.cmbConexiones.currentText()

        if not nombre:
            return

        datos = obtener_parametros(nombre)

        #self.txtLog.appendPlainText("")
        #self.txtLog.appendPlainText(f"Conexión seleccionada: {nombre}")

        # Llenar controles con la información de QGIS
        self.txtServidor.setText(datos.get("host", ""))
        self.spPuerto.setValue(int(datos.get("port", 5432)))
        self.txtBD.setText(datos.get("database", ""))
        self.txtUsuario.setText(datos.get("username", ""))
        self.txtPassword.setText(datos.get("password", ""))

        self.lblEstado.setText("🟡 Datos cargados. Listo para conectar.")

    def validar_tipos(self):

        for campo, datos_catalogo in self.catalogo.items():

            if campo not in self.featureclass:
                continue

            tipo_catalogo = obtener_tipo_catalogo(
            datos_catalogo["tipo_dato"]
            )

            tipo_bd = self.featureclass[campo]["tipo_base"]

            if tipo_catalogo.lower() == tipo_bd.lower():

                self.actualizar_resultado(
                campo,
                "Tipo",
                "✔"
                )

            else:

                #errores += 1

                self.actualizar_resultado(
                campo,
                "Tipo",
                "❌"
                )

                self.actualizar_resultado(
                campo,
                "Observaciones",
                f"|Tipo| Esperado: {tipo_catalogo} - Encontrado: {tipo_bd}"
                )

    def validar_longitudes(self):

        for campo, datos_catalogo in self.catalogo.items():

            # Si el campo no existe ya fue reportado
            if campo not in self.featureclass:
                continue

            longitud_catalogo = datos_catalogo["longitud"]

            longitud_bd = self.featureclass[campo]["longitud"]

            # Si el catálogo no especifica longitud, no validar
            if longitud_catalogo is None:
                
               self.actualizar_resultado(
                campo,
                "Longitud",
                "➖"
               )

               self.actualizar_resultado(
                campo,
                "Observaciones",
                "|Longitud| No aplica"
               )
               continue

            # Algunos tipos (date, integer, geometry, etc.)
            # no tienen longitud física
            if longitud_bd is None:
                
               self.actualizar_resultado(
                campo,
                "Longitud",
                "➖"
               )

               self.actualizar_resultado(
                campo,
                "Observaciones",
                "|Longitud| No aplica"
               )
               continue

            if int(longitud_catalogo) == int(longitud_bd):

                self.actualizar_resultado(
                campo,
                "Longitud",
                "✔"
                )

            else:

                self.actualizar_resultado(
                campo,
                "Longitud",
                "❌"
                )

                self.actualizar_resultado(
                campo,
                "Observaciones",
                f"|Longitud| Esperada: {longitud_catalogo} - Encontrada: {longitud_bd}"
            )

    def validar(self):
        self.progressBar.setValue(0)
        QApplication.processEvents()
        try:
           
            self.limpiar_resultados()

            self.tabs.setCurrentWidget(self.tabResultados)

            objeto = self.cmbObjetoCat.currentText()
            #if not objeto : 
            #    self.txtLog.appendPlainText("Debe seleccionar un objeto del catalogo")

            #    return
            if self.conn_usuario is None or self.conn_catalogo is None:

                QMessageBox.warning(
                    self,
                    "Sin conexión",
                    "No existe una conexión activa con la base de datos \n\n"
                    "Primero conecte a una Base de Datos"
                )
                return

            # =====================================
            # Leer catálogo
            # =====================================

            columnas, registros = leer_catalogo_objeto(
            self.conn_catalogo,
            objeto
            #self.objeto_catalogo
            )

            self.catalogo = procesar_catalogo(registros)

            # =====================================
            # Leer estructura de la Feature Class
            # =====================================

            esquema = self.label_esquema.text()

            tabla = self.cmbFeatureClass.currentText()

            self.featureclass = obtener_campos(
            self.conn_usuario,
            esquema,
            tabla
            )
             
            # =====================================
            # Ejecutar validaciones seleccionadas
            # =====================================
            
            validaciones = []
            if self.chkCampos.isChecked():
                validaciones.append("Campos")
                self.validar_campos()
                self.progressBar.setValue(10)
                QApplication.processEvents()


            if self.chkTipos.isChecked():
                validaciones.append("Tipos")
                self.validar_tipos()
                self.progressBar.setValue(20)
                QApplication.processEvents()


            if self.chkLongitud.isChecked():
                validaciones.append("Longitud")
                self.validar_longitudes()
                self.progressBar.setValue(30)
                QApplication.processEvents()


            if self.chkValores.isChecked():
                validaciones.append("Valores")
                self.validar_valores()

            # 1. Primero validamos si la lista está vacía
            if not validaciones:  # Opción limpia y correcta en Python
                QMessageBox.warning(
                self,
                "Validación",
                "Debe seleccionar al menos una validación antes de continuar"
                )
            else:

                self.tblResultados.resizeRowsToContents()
            # 2. Si tiene elementos, mostramos el éxito
                QMessageBox.information(
                self,
                "Validación terminada",
                "Se ejecutaron correctamente las siguientes validaciones: \n\n"
                + "\n".join(f"✓ {v}" for v in validaciones)
            )

        except Exception as e:

            if self.conn_usuario:
                self.conn_usuario.rollback()

            if self.conn_catalogo:
                self.conn_catalogo.rollback()

            self.txtLog.appendPlainText("")
            self.txtLog.appendPlainText("========ERROR========")
            #self.txtLog.appendPlainText(str(e))

            self.txtLog.appendPlainText(traceback.format_exc())

            

            QMessageBox.critical(
                self,
                "Error",
                "Ocurrió un error durante la validación \n\n"
                "Revise la prestaña Log para mas información"
            )

    def actualizar_resultado(self, campo, columna, valor):

        if campo not in self.filas:
            self.crear_fila(campo)

        fila = self.filas[campo]

        columnas = {

        "Existe": 1,
        "Tipo": 2,
        "Longitud": 3,
        "Valores": 4,        
        "Observaciones": 5

        }

        col = columnas[columna]

        # ==========================================
        # Columna Observaciones
        # ==========================================

        if columna == "Observaciones":

            item_actual = self.tblResultados.item(fila, col)

            if item_actual is None or item_actual.text() == "":

                texto = "• " + str(valor)

            else:

                texto = item_actual.text() + "\n• " + str(valor)

            item = QTableWidgetItem(texto)
            item.setToolTip(texto)

        # ==========================================
        # Resto de columnas
        # ==========================================

        else:

            item = QTableWidgetItem(str(valor))

            if valor == "✔":

                item.setBackground(QColor(198, 239, 206))
                item.setForeground(QColor(0, 97, 0))

            elif valor == "❌":

                item.setBackground(QColor(255, 199, 206))
                item.setForeground(QColor(156, 0, 6))

            elif valor == "➕":

                item.setBackground(QColor(255, 235, 156))
                item.setForeground(QColor(156, 101, 0))

            elif valor == "➖":

                item.setBackground(QColor(255, 242, 204))
                item.setForeground(QColor(127, 96, 0))

        self.tblResultados.setItem(
        fila,
        col,
        item
        )

    def crear_fila(self, campo):
        """
        Crea una fila para un campo si aún no existe.
        """

        if campo in self.filas:
            return

        fila = self.tblResultados.rowCount()

        self.tblResultados.insertRow(fila)

        self.tblResultados.setItem(
        fila,
        0,
        QTableWidgetItem(campo)
        )

        # Inicializar las demás columnas vacías
        for columna in range(1, 6):
            self.tblResultados.setItem(
            fila,
            columna,
            QTableWidgetItem("")
            )

        self.filas[campo] = fila

    def limpiar_resultados(self):

        self.tblResultados.clear()

        self.tblResultados.setColumnCount(6)

        self.tblResultados.setHorizontalHeaderLabels([
        "Campo",
        "Existe",
        "Tipo",
        "Longitud",
        "Valores",
        "Observaciones"
        ])
        self.tblResultados.setRowCount(0)
        self.filas = {}

        header = self.tblResultados.horizontalHeader()

        header.setStretchLastSection(True)


    def validar_campos(self):

        # =====================================
        # Validar campos del catálogo normal
        # =====================================
        for campo in self.catalogo:

            if campo in self.featureclass:

                self.actualizar_resultado(
                campo,
                "Existe",
                "✔"
                )

            else:

                self.actualizar_resultado(
                campo,
                "Existe",
                "❌"
                )

                self.actualizar_resultado(
                campo,
                "Observaciones",
                "|Existe| Campo inexistente"
                )


        # =====================================
        # Leer atributos de implementación
        # =====================================
        self.txtLog.appendPlainText("")
        self.txtLog.appendPlainText(
        "===== ATRIBUTOS DE IMPLEMENTACIÓN ====="
        )

        objeto = self.cmbObjetoCat.currentText()

        columnas_imp, registros_imp = leer_atributos_implementacion(
        self.conn_catalogo,
        objeto
        )

        campos_implementacion = {}

        for fila in registros_imp:

            nombre_campo = fila[3]

            if nombre_campo is None:
                continue

            nombre_campo = nombre_campo.strip().lower()

            if nombre_campo:
                campos_implementacion[nombre_campo] = fila

        self.txtLog.appendPlainText(
        f"Atributos de implementación encontrados: "
        f"{len(campos_implementacion)}"
        )

        # =====================================
        # Información de implementación
        # =====================================
        # Se consulta de manera independiente.
        # NO participa en la validación de "Existe"
        # ni en la detección de "Campo adicional".
        # =====================================

        for campo in campos_implementacion:

            existe_en_featureclass = campo in self.featureclass

            """self.txtLog.appendPlainText(
            f"Implementación - {campo}: "
            f"{'Existe en Feature Class' if existe_en_featureclass else 'No existe en Feature Class'}"
            )"""
            self.actualizar_resultado(
                campo,
                "Existe",
                "❌"
                )
            self.actualizar_resultado(
                campo,
                "Tipo",
                "❌"
                )
            self.actualizar_resultado(
                campo,
                "Longitud",
                "❌"
                )  
            self.actualizar_resultado(
                campo,
                "Valores",
                "❌"
                )                              
            self.actualizar_resultado(
                campo,
                "Observaciones",
                f"Implementación - {campo}: "
                f"{'Existe en Feature Class pero no en catálogo' if existe_en_featureclass else 'No existe en Feature Class'}"
                    )
        for campo in self.featureclass:

            campo_normalizado = campo.strip().lower()

            if campo_normalizado not in self.catalogo:

                if campo_normalizado in campos_implementacion:
                    self.actualizar_resultado(
                        campo,
                        "Existe",
                        "➕"
                    )

                else:

                    self.actualizar_resultado(
                    campo,
                    "Existe",
                    "➕"
                    )

                    self.actualizar_resultado(
                    campo,
                    "Observaciones",
                    "Campo adicional"
                    )
    def agregar_resultado(self, campo, estado, observacion):

        fila = self.tblResultados.rowCount()

        self.tblResultados.insertRow(fila)

        self.tblResultados.setItem(
        fila,
        0,
        QTableWidgetItem(campo)
        )

        self.tblResultados.setItem(
        fila,
        1,
        QTableWidgetItem(estado)
        )

        self.tblResultados.setItem(
        fila,
        2,
        QTableWidgetItem(observacion)
        )

    def conectar_bd(self):

        self.cerrar_conexiones()

        #self.txtLog.appendPlainText("=== Entró a conectar_bd ===")
        datos = {
        "host": self.txtServidor.text().strip(),
        "port": self.spPuerto.value(),
        "database": self.txtBD.text().strip(),
        "username": self.txtUsuario.text().strip(),
        "password": self.txtPassword.text(),
        "sslmode": "prefer"
        }
        # Validaciones
        if not datos["host"]:
            #self.txtLog.appendPlainText("ERROR: Debe indicar el servidor.")
            QMessageBox.warning(
                self,
                "Validación",
                "Debe indicar el servidor antes de continuar"
            )
            return

        if not datos["database"]:
            #self.txtLog.appendPlainText("ERROR: Debe indicar la base de datos.")
            QMessageBox.warning(
                self,
                "Validación",
                "Debe indicar la base de datos antes de continuar"
            )
            return

        if not datos["username"]:
            #self.txtLog.appendPlainText("ERROR: Debe indicar el usuario.")
            QMessageBox.warning(
                self,
                "Validación",
                "Debe indicar el usuario antes de continuar"
            )
            self.txtUsuario.setFocus()
            return

        if not datos["password"]:
            #self.txtLog.appendPlainText("ERROR: Debe indicar la contraseña.")
            QMessageBox.warning(
                self,
                "Validación",
                "Debe indicar la contraseña antes de continuar"
            )
            self.txtPassword.setFocus()
            return
            
        try:

            self.conn_usuario = conectar(datos)
            self.conn_catalogo = conectar(CATALOGO)

            self.objetos_catalogo = obtener_objetos_catalogo(
            self.conn_catalogo
            )

            self.cmbObjetoCat.clear()
            self.cmbObjetoCat.addItems(self.objetos_catalogo)        
            # aqui mero va el merenquetengue 
            self.lblEstado.setText(
            f"🟢 Conectado a {datos['database']}"
            )

            self.lblCatalogo.setText(
                "🟢 cog_w.cog_cat_valores_vw"
            )

            # Mostrar el esquema utilizado
            self.label_esquema.setText(datos["username"])            

            #self.txtLog.appendPlainText(
            #"Conexión establecida correctamente."
            #)

            featureclass = obtener_featureclass(
            self.conn_usuario,
             datos["username"]
            )

            self.cmbFeatureClass.clear()

            self.cmbFeatureClass.addItems(featureclass)
            QMessageBox.information(
                self,
                "Conexión",
                "La conexión a la base de datos se realizó correctamente"
            )


        except Exception as e:

            self.conn_usuario = None
            self.conn_catalogo = None

            self.lblEstado.setText("🔴 Sin conexión")

            self.lblCatalogo.setText("🔴 Error al conectar catálogo")

            self.txtLog.appendPlainText(f"ERROR: {e}")

            QMessageBox.critical(
            self,
            "Error de conexión",
            "No fue posible establecer la conexión con la base de datos.\n\n"
            "Revise la pestaña 'Log' para conocer el detalle del error."
            )

    def cerrar_conexiones(self):
        if self.conn_usuario:

            self.conn_usuario.close()
            self.conn_usuario = None

        if self.conn_catalogo:

            self.conn_catalogo.close()
            self.conn_catalogo = None

        self.lblEstado.setText("🔴 Sin conexión")

    def closeEvent(self,event):

        self.cerrar_conexiones()

        event.accept()

    """def validar_valores(self):
        esquema = self.label_esquema.text()

        tabla = self.cmbFeatureClass.currentText()
        total = len(self.catalogo)
        #self.txtLog.appendPlainText("")
        #self.txtLog.appendPlainText("===== PRUEBA VALIDAR VALORES =====")
        #self.txtLog.appendPlainText(str(type(self.catalogo)))
        #self.txtLog.appendPlainText(str(self.catalogo))

        for i,(campo, datos) in enumerate(self.catalogo.items(), start=1):
            progreso = 30 + int(i * 70/total)
            self.progressBar.setValue(progreso)
            QApplication.processEvents()

            if campo in CAMPOS_SIN_VALIDAR_VALORES:
                self.actualizar_resultado(
                campo,
                "Valores",
                "➖"
                )
                self.actualizar_resultado(
                campo,
                "Observaciones",
                "|Valores| No aplica"
                )
                continue
            if campo not in self.featureclass:
                self.actualizar_resultado(
                    campo,
                    "Valores",
                    "➖"
                )
                self.actualizar_resultado(
                    campo,
                    "Observaciones",
                    "Valores: No se valida porque el campo no existe en el featureclass"
                )
                continue

            valores = obtener_valores_distintos(
                self.conn_usuario,
                esquema,
                tabla,
                campo
            )
            reglas_catalogo = datos["valores"]
            
            consultas = [
            r for r in datos["valores"]
            if r is not None
            and str(r).strip().lower().startswith("consultar")
            ]

            reglas_catalogo = [
            r for r in datos["valores"]
            if r is not None
            and not str(r).strip().lower().startswith("consultar")
            ]

            if consultas:

               self.actualizar_resultado(
               campo,
               "Valores",
               "➖"
               )

               self.actualizar_resultado(
               campo,
               "Observaciones",
               "|Valores| " +consultas[0]
               )
               continue       
            

            tipo = tipo_regla(reglas_catalogo)

            if tipo == "LITERAL":

               correcto, invalidos = validar_literal(
               valores,
               reglas_catalogo
               )

               if correcto:

                  self.actualizar_resultado(
                  campo,
                  "Valores",
                  "✔"
                )

               else:

                   self.actualizar_resultado(
                   campo,
                   "Valores",
                   "❌"
                   )

                   self.actualizar_resultado(
                    campo,
                    "Observaciones",
                    "|Valores| No permitidos: "
                    + ", ".join(invalidos)
                   )

            elif tipo =="INTERVALO":

                correcto, invalidos = validar_intervalo(
                valores,
                reglas_catalogo
                )

                if correcto:

                    self.actualizar_resultado(
                        campo,
                        "Valores",
                        "✔"
                    )

                else:

                    self.actualizar_resultado(
                        campo,
                        "Valores",
                        "❌"
                    )

                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        f"|Valores| Fuera del intervalo: {', '.join(invalidos)}"
                    )

            elif tipo =="COMPARACION":

                correcto, invalidos = validar_comparacion(
                valores,
                reglas_catalogo
                )

                if correcto:

                    self.actualizar_resultado(
                        campo,
                        "Valores",
                        "✔"
                    )

                else:

                    self.actualizar_resultado(
                        campo,
                        "Valores",
                        "❌"
                    )

                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        f"|Valores| Fuera del rango permitido: {', '.join(invalidos)}"
                        #+ ", ".join(invalidos)
                    )  

            elif tipo =="COMPUESTA":

                correcto, invalidos = validar_compuesta(
                    valores, reglas_catalogo
                )       

                if correcto:

                   self.actualizar_resultado(
                   campo,
                   "Valores",
                   "✔"
                   )

                else:

                   self.actualizar_resultado(
                   campo,
                   "Valores",
                   "❌"
                   )

                   self.actualizar_resultado(
                   campo,
                   "Observaciones",
                   f"|Valores| inválidos: {', '.join(invalidos)}"
                   )

            elif tipo =="ESTRUCTURA":

                correcto, invalidos = validar_estructura(
                    valores, reglas_catalogo
                )

                if correcto:

                    self.actualizar_resultado(
                        campo,
                        "Valores",
                        "✔"
                    )
                else:

                    self.actualizar_resultado(
                        campo,
                        "Valores",
                        "❌"
                    )

                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        f"|Valores| inválidos de estructura: {', '.join(invalidos)}"
                    )"""

    def validar_valores(self):
        esquema = self.label_esquema.text()
        tabla = self.cmbFeatureClass.currentText()
        total = len(self.catalogo)
     
        for i, (campo, datos) in enumerate(
            self.catalogo.items(), start=1
        ):
            progreso = 30 + int(i * 70 / total) if total else 100
            self.progressBar.setValue(progreso)
            QApplication.processEvents()
     
            # =====================================
            # Campos que no requieren validación
            # =====================================
            if campo in CAMPOS_SIN_VALIDAR_VALORES:
                self.actualizar_resultado(campo, "Valores", "➖")
                self.actualizar_resultado(
                    campo, "Observaciones", "|Valores| No aplica"
                )
                continue
     
            # =====================================
            # Comprobar existencia del campo
            # =====================================
            if campo not in self.featureclass:
                self.actualizar_resultado(campo, "Valores", "➖")
                self.actualizar_resultado(
                    campo,
                    "Observaciones",
                    "Valores: No se valida porque el campo no existe en el featureclass"
                )
                continue
     
            # =====================================
            # Obtener valores de la Feature Class
            # =====================================
            valores = obtener_valores_distintos(
                self.conn_usuario,
                esquema,
                tabla,
                campo
            )
     
            reglas_originales = datos["valores"]
     
            consultas = [
                r for r in reglas_originales
                if r is not None
                and str(r).strip().lower().startswith("consultar")
            ]
     
            reglas_catalogo = [
                r for r in reglas_originales
                if r is not None
                and not str(r).strip().lower().startswith("consultar")
            ]
     
            # =====================================
            # Reglas que indican consultar catálogo
            # =====================================
            if consultas:
                self.actualizar_resultado(campo, "Valores", "➖")
                self.actualizar_resultado(
                    campo,
                    "Observaciones",
                    "|Valores| " + str(consultas[0])
                )
                continue
     
            # =====================================
            # Valores especiales del catálogo
            # =====================================
            reglas_normalizadas = [
                str(r).strip().casefold()
                for r in reglas_catalogo
                if r is not None
            ]
     
            # Si el catálogo contiene Indeterminado,
            # cualquier valor de la Feature Class es válido.
            permite_indeterminado = any(
                "indeterminado" in regla
                for regla in reglas_normalizadas
            )
     
            if permite_indeterminado:
                self.actualizar_resultado(campo, "Valores", "✔")
                continue
     
            # Comprobar si el catálogo permite N/D y N/A.
            permite_nd = any(
                "no disponible" in regla and "n/d" in regla
                for regla in reglas_normalizadas
            )
     
            permite_na = any(
                "no aplica" in regla and "n/a" in regla
                for regla in reglas_normalizadas
            )
     
            # Excluir de la validación normal únicamente
            # los valores especiales permitidos.
            valores_validar = []
     
            for valor in valores:
                valor_normalizado = (
                    str(valor).strip().casefold()
                    if valor is not None
                    else None
                )
     
                if permite_nd and valor_normalizado == "n/d":
                    continue
     
                if permite_na and valor_normalizado == "n/a":
                    continue
     
                valores_validar.append(valor)
     
            # =====================================
            # Determinar tipo de regla
            # =====================================
            tipo = tipo_regla(reglas_catalogo)
     
            if tipo == "LITERAL":
                correcto, invalidos = validar_literal(
                    valores_validar,
                    reglas_catalogo
                )
     
                if correcto:
                    self.actualizar_resultado(campo, "Valores", "✔")
                else:
                    self.actualizar_resultado(campo, "Valores", "❌")
                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        "|Valores| No permitidos: "
                        + ", ".join(invalidos)
                    )
     
            elif tipo == "INTERVALO":
                correcto, invalidos = validar_intervalo(
                    valores_validar,
                    reglas_catalogo
                )
     
                if correcto:
                    self.actualizar_resultado(campo, "Valores", "✔")
                else:
                    self.actualizar_resultado(campo, "Valores", "❌")
                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        "|Valores| Fuera del intervalo: "
                        + ", ".join(invalidos)
                    )
     
            elif tipo == "COMPARACION":
                correcto, invalidos = validar_comparacion(
                    valores_validar,
                    reglas_catalogo
                )
     
                if correcto:
                    self.actualizar_resultado(campo, "Valores", "✔")
                else:
                    self.actualizar_resultado(campo, "Valores", "❌")
                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        "|Valores| Fuera del rango permitido: "
                        + ", ".join(invalidos)
                    )
     
            elif tipo == "COMPUESTA":
                correcto, invalidos = validar_compuesta(
                    valores_validar,
                    reglas_catalogo
                )
     
                if correcto:
                    self.actualizar_resultado(campo, "Valores", "✔")
                else:
                    self.actualizar_resultado(campo, "Valores", "❌")
                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        "|Valores| inválidos: "
                        + ", ".join(invalidos)
                    )
     
            elif tipo == "ESTRUCTURA":
                correcto, invalidos = validar_estructura(
                    valores_validar,
                    reglas_catalogo
                )
     
                if correcto:
                    self.actualizar_resultado(campo, "Valores", "✔")
                else:
                    self.actualizar_resultado(campo, "Valores", "❌")
                    self.actualizar_resultado(
                        campo,
                        "Observaciones",
                        "|Valores| inválidos de estructura: "
                        + ", ".join(invalidos)
                    )
     
            else:
                self.actualizar_resultado(campo, "Valores", "➖")
                self.actualizar_resultado(
                    campo,
                    "Observaciones",
                    "|Valores| No se pudo determinar el tipo de regla"
                )